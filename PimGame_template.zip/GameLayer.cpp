#include "stdafx.h"
#include "GameLayer.h"


GameLayer::GameLayer(void)
{
	font = NULL;
	label = NULL;
}
GameLayer::~GameLayer(void)
{
	if (font != NULL) delete font;
}

void GameLayer::loadResources()
{
	listenMouse();

	font = new Pim::Font("arial.ttf", 50);

	label = new Pim::Label(font, "Hello, World!");
	label->giveOwnershipOfFont();
	label->setTextAlignment(Pim::Text::TEXT_CENTER);
	label->position = Pim::Vec2(10.f, 10.f);
	label->color = Pim::Color(0.f, 0.f, 0.f, 1.f);
	addChild(label);
}

void GameLayer::mouseEvent(Pim::MouseEvent &evt)
{
	label->position = evt.getPosition();

	std::cout<< evt.getPosition().x		<<","
			 << evt.getPosition().y		<<"\n";
}
