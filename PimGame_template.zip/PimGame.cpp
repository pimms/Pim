// Pim_Template.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "Pim.h"
#include "GameLayer.h"

int _tmain(int argc, _TCHAR* argv[])
{
	Pim::WinStyle::CreationData cd(
		"Hello, World!", 
		800,
		600,
		Pim::WinStyle::WINDOWED
		);
	cd.coordinateSystem = Pim::Vec2(20.f, 20.f);

	Pim::GameControl *gc = new Pim::GameControl();
	gc->go(new GameLayer, cd);
	delete gc;

	return 0;
}

