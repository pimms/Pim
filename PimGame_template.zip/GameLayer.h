#pragma once
#include "Pim.h"

class GameLayer : public Pim::Layer
{
public:
	GameLayer(void);
	~GameLayer(void);

	void loadResources();

	void mouseEvent(Pim::MouseEvent &evt);

	Pim::Font		*font;
	Pim::Label		*label;
};

