========================================================================
                       PimGame template README
========================================================================

1. Open your command window

2. Enter the command:
?> setx PIM_HOME <path_to_wherever_you_put_Pim>

3. Open the project in Visual Studio

4. Enjoy!