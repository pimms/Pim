#include "StdAfx.h"
#include "TestNode.h"


TestNode::TestNode(void)
{
	listenFrame();
}

void TestNode::update(float dt)
{

}

