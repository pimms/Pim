#pragma once
#include "Pim.h"

class TestNode : public Pim::GameNode
{
public:
	TestNode(void);

	void update(float dt);
	
};

